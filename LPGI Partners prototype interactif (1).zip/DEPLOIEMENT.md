# Mise en production — EMKAY Partners × LPGI

URL cible : **https://emkay-partners-lpgi.brussels**

## 1. Domaine — à vérifier (non confirmé)
- [ ] Vérifier la disponibilité de `emkay-partners-lpgi.brussels` (registrar agréé .brussels, ex. via DNS Belgium).
- [ ] Vérifier qu'il est enregistré au nom d'EMKAY PARTNERS SRL.
- [ ] Obtenir l'accès à la zone DNS.

## 2. Hébergement (Vercel)
- [ ] Importer ce dossier dans un projet Vercel (site statique, aucune build requise).
- [ ] `vercel.json` sert la page principale à la racine `/` et ajoute les en-têtes de sécurité (HSTS, etc.).
- [ ] Settings → Domains : ajouter `emkay-partners-lpgi.brussels` (+ `www.` en redirection).
- [ ] DNS : enregistrement A `@` → 76.76.21.21 et CNAME `www` → cname.vercel-dns.com (valeurs à confirmer dans le tableau de bord Vercel).
- [ ] HTTPS : certificat émis automatiquement par Vercel ; HTTP → HTTPS redirigé automatiquement.

## 3. Avant de générer le QR code définitif
- [ ] Le site répond en HTTPS sur le domaine final, depuis un réseau mobile.
- [ ] Les 12 fiches s'ouvrent ; tous les liens « Visiter leur site web ↗ » fonctionnent.
- [ ] Mentions légales (#/mentions-legales) et Confidentialité (#/confidentialite) accessibles.
- [ ] Test sur iPhone et Android (320 / 375 / 390 / 430 px).
- [ ] Aperçu de partage : tester l'URL dans WhatsApp et sur https://www.opengraph.xyz.
- [ ] Ajouter `og-image.png` (1200×630) et `icon-512.png` à la racine — fichiers référencés mais pas encore fournis.
- [ ] Compléter l'hébergeur dans les mentions légales (data/legal.js).
- [ ] Générer le QR code vers `https://emkay-partners-lpgi.brussels`, puis le scanner pour validation.

## Métadonnées
- Titre navigateur : EMKAY Partners × LPGI
- Titre de partage : EMKAY Partners × LPGI — Les rencontres commencent ici
- Nom court : EMKAY × LPGI
- Titre interdit (absent du projet) : « LPGI Partners | Découvrez les partenaires de la soirée »
