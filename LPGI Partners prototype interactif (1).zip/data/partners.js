// LPGI Partners — données partenaires (éditables)
// primaryColor = couleur de marque · secondaryColor = 2e couleur · contrastColor = version lisible sur fond sombre (textes, accents).
// plateColor : fond de la plaque derrière le logo (adapté au fichier fourni). plateBackground (optionnel) : dégradé CSS si le fichier en contient un.
// logoUrl : null = emplacement « logo à fournir » affiché. Idéalement héberger les fichiers dans /logos.
// colorsConfirmed : false = couleurs PROVISOIRES à remplacer par la charte réelle du partenaire.
// representativeName / meetingLocation : null tant que l'organisateur ne les a pas communiqués.
// contentSource : 'site' = enrichi depuis le site officiel ; 'brief' = base éditoriale à valider.

// displayOrder : ordre d'affichage imposé (liste, recherche, filtres). Pas de tri alphabétique.
// experience: true → fiche adaptée (« Vous devriez les découvrir si... », bouton « Découvrir ce partenaire » tant qu'aucun représentant n'est confirmé).
// website : null = bouton « Visiter leur site web » masqué jusqu'à validation d'une URL officielle.

window.LPGI_CATEGORIES = [
  { id: 'immo', label: 'Immobilier' },
  { id: 'reno', label: 'Construction' },
  { id: 'energie', label: 'Énergie' },
  { id: 'tech', label: 'Technologie' },
  { id: 'com', label: 'Communication' },
  { id: 'food', label: 'Restauration & Bar' },
];

window.LPGI_PARTNERS = [
  {
    id: 'renovsecure', displayOrder: 5, name: "RenovSecure", initials: 'RS',
    logoUrl: 'logos/renovsecure.png', plateColor: '#0B1418',
    primaryColor: '#C9611A', secondaryColor: '#FFFFFF', contrastColor: '#F39A55', colorsConfirmed: false,
    website: 'https://renovsecure.be/', websiteNote: null,
    cats: ["reno","immo"], category: "Rénovation • Construction • Vérification",
    shortDescription: "Sécurisez vos décisions avant d'engager vos travaux.",
    detailedDescription: "RenovSecure est un label privé réunissant différentes expertises pour mieux encadrer, vérifier et documenter les projets de rénovation, de transformation et de construction.",
    services: ["Encadrement des projets de rénovation et de construction","Vérification avant engagement des travaux","Documentation du projet"],
    meetIf: ["Vous préparez un projet de rénovation ou de construction.","Vous souhaitez sécuriser vos décisions avant d'engager des travaux.","Vous recherchez un accompagnement structuré pour votre projet immobilier."],
    keywords: "travaux chantier label vérification encadrement transformation extension construction rénovation",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'colively', displayOrder: 4, name: "Colively", initials: 'CO',
    logoUrl: 'logos/colively.svg', plateColor: '#1F7163',
    primaryColor: '#1F7163', secondaryColor: '#F3FBF6', contrastColor: '#5CC4AE', colorsConfirmed: true,
    website: 'https://colively.app/', websiteNote: null,
    cats: ["immo","tech"], category: "Immobilier • Technologie • IA",
    shortDescription: "La maintenance de vos biens, simplifiée grâce à l'IA.",
    detailedDescription: "Colively est une solution digitale de gestion de maintenance immobilière. Elle facilite le traitement des signalements, les échanges entre les parties prenantes et le suivi des interventions grâce à des fonctionnalités d'automatisation et d'intelligence artificielle.",
    services: ["Traitement des signalements","Échanges entre les parties prenantes","Suivi automatisé des interventions"],
    meetIf: ["Vous gérez plusieurs biens immobiliers ou locatifs.","Vous souhaitez automatiser le suivi des demandes de maintenance.","Vous recherchez une solution pour centraliser les interventions techniques."],
    keywords: "maintenance locative locataires gestion signalement intervention ia intelligence artificielle automatisation application",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'asbuilt', displayOrder: 1, name: "As Built", initials: 'AB',
    logoUrl: 'logos/as-built.png', plateColor: '#FFFFFF',
    primaryColor: '#000000', secondaryColor: '#FFFFFF', contrastColor: '#E6E6E6', colorsConfirmed: true,
    website: 'https://asbuilt.be/fr/home-fr/', websiteNote: null,
    cats: ["reno","immo"], category: "Électricité • Mise en conformité • Immobilier",
    shortDescription: "Vos installations électriques, conformes et sécurisées.",
    detailedDescription: "As Built accompagne les particuliers dans leurs travaux électriques domestiques et leurs démarches de mise en conformité, notamment grâce à un réseau de partenaires spécialisés.",
    services: ["Travaux électriques domestiques","Démarches de mise en conformité électrique","Réseau de partenaires spécialisés"],
    meetIf: ["Vous devez mettre une installation électrique en conformité.","Vous préparez des travaux électriques dans un bien immobilier.","Vous recherchez un professionnel pour vous accompagner dans vos obligations électriques."],
    keywords: "électricité électrique électricien conformité mise en conformité contrôle installation travaux",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'dcexpertises', displayOrder: 3, name: "De Clerck Expertises", initials: 'DC',
    logoUrl: 'logos/de-clerck-expertises.jpeg', plateColor: '#F6F1EA',
    primaryColor: '#1C2F4A', secondaryColor: '#B98A4E', contrastColor: '#D4A86A', colorsConfirmed: true,
    website: 'https://www.dc-expertises.be/', websiteNote: null,
    cats: ["immo"], category: "Expertise immobilière",
    shortDescription: "Des expertises immobilières claires et impartiales.",
    detailedDescription: "De Clerck Expertises accompagne particuliers et professionnels dans leurs besoins d'états des lieux, d'évaluations immobilières et de conseils techniques.",
    services: ["États des lieux","Évaluations immobilières","Conseils techniques"],
    meetIf: ["Vous devez réaliser un état des lieux.","Vous souhaitez faire évaluer un bien immobilier.","Vous recherchez une expertise technique ou immobilière indépendante."],
    keywords: "état des lieux évaluation expertise estimation de clerck dc expertises conseil technique",
    representativeName: null, meetingLocation: null, contentSource: 'site',
  },
  {
    id: 'workpilot', displayOrder: 6, name: "WorkPilot", initials: 'WP',
    logoUrl: 'logos/workpilot.png', plateColor: '#FFFFFF',
    primaryColor: '#EF3E06', secondaryColor: '#FFFFFF', contrastColor: '#FF7A4D', colorsConfirmed: true,
    website: 'https://www.work-pilot.be/', websiteNote: null,
    cats: ["reno"], category: "Construction • Artisans • Indépendants",
    shortDescription: "Le bon renfort pour vos chantiers, au bon moment.",
    detailedDescription: "WorkPilot facilite la mise en relation entre les acteurs de la construction ayant besoin de renforts ou de remplacements et des professionnels indépendants disponibles.",
    services: ["Mise en relation avec des professionnels indépendants","Renforts et remplacements pour vos missions","Nouvelles opportunités pour les indépendants du bâtiment"],
    meetIf: ["Vous dirigez une entreprise de construction et recherchez des professionnels indépendants.","Vous devez renforcer une équipe ou organiser un remplacement.","Vous êtes indépendant dans le secteur du bâtiment et recherchez de nouvelles missions."],
    keywords: "chantier chantiers construction bâtiment artisan artisans renfort remplacement indépendant mission mise en relation",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'alenergy', displayOrder: 8, name: "AL Energy", initials: 'AL',
    logoUrl: 'logos/al-energy.webp',
    plateColor: '#FFFFFF',
    primaryColor: '#1E8A55', secondaryColor: '#3FBF7F', contrastColor: '#5FD49A', colorsConfirmed: false,
    website: 'https://www.alenergy.be/', websiteNote: null,
    cats: ["energie","immo"], category: "Énergie • Certification PEB • Immobilier",
    shortDescription: "Votre certificat PEB à Bruxelles, remis le jour de la visite.",
    detailedDescription: "AL Energy réalise des certifications PEB officielles à Bruxelles, avec une procédure permettant la remise du certificat dès la visite, selon les conditions de son service.",
    services: ["Certification PEB officielle à Bruxelles","Remise du certificat dès la visite, selon conditions","Certification pour une vente ou une location"],
    meetIf: ["Vous avez besoin d'un certificat PEB à Bruxelles.","Vous préparez la vente ou la location d'un bien immobilier.","Vous souhaitez obtenir rapidement votre certification énergétique."],
    keywords: "peb certificat certification énergie énergétique bruxelles vente location",
    representativeName: null, meetingLocation: null, contentSource: 'site',
  },
  {
    id: 'phoenixmaster', displayOrder: 7, name: "Phoenix Master", initials: 'PM',
    logoUrl: 'logos/phoenix-master.webp', plateColor: '#FFFFFF',
    primaryColor: '#1A1A1A', secondaryColor: '#FFFFFF', contrastColor: '#E6E6E6', colorsConfirmed: true,
    website: 'https://phoenix-master.be/', websiteNote: null,
    cats: ["reno","immo"], category: "Entretien • Nettoyage • Rénovation",
    shortDescription: "Un seul partenaire pour entretenir et valoriser vos biens.",
    detailedDescription: "Phoenix Master propose des prestations de nettoyage professionnel, d'entretien, de rénovation et de remise en état de biens immobiliers.",
    services: ["Nettoyage professionnel","Entretien de bâtiments","Rénovation et remise en état"],
    meetIf: ["Vous souhaitez entretenir régulièrement vos bâtiments.","Vous devez remettre un bien en état avant une vente ou une location.","Vous recherchez un partenaire pour des travaux de rénovation ou de nettoyage."],
    keywords: "nettoyage entretien remise en état rénovation bâtiment",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'phenixict', displayOrder: 2, name: "Phenix-ICT", initials: 'PI',
    logoUrl: 'logos/phenix-ict.png', plateColor: '#00263F',
    primaryColor: '#00263F', secondaryColor: '#EE741B', contrastColor: '#F08A3E', colorsConfirmed: true,
    website: 'https://phenixict.tech/fr/home-francais/', websiteNote: null,
    cats: ["tech"], category: "Informatique • Cybersécurité • Cloud",
    shortDescription: "Une informatique fiable et sécurisée pour votre entreprise.",
    detailedDescription: "Phenix-ICT accompagne les entreprises dans la sécurisation et la gestion de leur environnement informatique : infrastructures, cybersécurité, maintenance IT et solutions cloud.",
    services: ["Infrastructures informatiques","Cybersécurité","Maintenance IT et solutions cloud"],
    meetIf: ["Vous souhaitez renforcer la cybersécurité de votre entreprise.","Vous avez besoin d'une assistance ou maintenance informatique.","Vous souhaitez moderniser votre infrastructure et vos solutions cloud."],
    keywords: "informatique it cybersécurité cloud maintenance réseau infrastructure assistance",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'emkay', displayOrder: 9, name: "EMKAY Partners", initials: 'EK',
    logoUrl: 'logos/emkay-partners-wordmark.png', plateColor: '#442A56', plateBackground: 'linear-gradient(180deg, #38224A, #54366B)',
    primaryColor: '#4B2F7A', secondaryColor: '#F2EFEA', contrastColor: '#C9B8E8', colorsConfirmed: true,
    website: 'https://emkaypartners.com/', websiteNote: null,
    cats: ["com"], category: "Communication • Audiovisuel • Événementiel",
    shortDescription: "Communication, contenus et événements pour donner de l'ampleur à vos projets.",
    detailedDescription: "EMKAY Partners est un groupe entrepreneurial qui développe plusieurs marques et accompagne les entreprises dans leur communication, leur production de contenus audiovisuels et l'organisation d'événements professionnels. EMKAY Partners est également le concepteur de la technologie LPGI Partners, exclusivement pour cet événement.",
    services: ["Communication et visibilité","Production de contenus audiovisuels","Organisation d'événements professionnels"],
    meetIf: ["Vous souhaitez développer votre communication et votre visibilité.","Vous avez besoin de contenus audiovisuels professionnels.","Vous souhaitez organiser un événement ou développer un projet entrepreneurial."],
    keywords: "communication marketing visibilité audiovisuel vidéo contenu événementiel événement marque entrepreneuriat",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'belgosun', displayOrder: 10, name: "Belgosun", initials: 'BS',
    logoUrl: 'logos/belgosun.png', plateColor: '#FFFFFF',
    primaryColor: '#2D3A9B', secondaryColor: '#FFFFFF', contrastColor: '#8E9BFF', colorsConfirmed: true,
    website: 'https://belgosun.be/', websiteNote: null,
    cats: ["energie","reno","immo"], category: "Énergie solaire • Photovoltaïque • Mobilité électrique",
    shortDescription: "Faites du soleil une énergie pour vos projets.",
    detailedDescription: "Belgosun accompagne particuliers et professionnels dans leurs projets photovoltaïques, l'installation de batteries de stockage, de bornes de recharge et l'optimisation des équipements énergétiques.",
    services: ["Installation de panneaux photovoltaïques","Installation de batteries de stockage","Installation de bornes de recharge","Raccordement électrique et mise en conformité","Dimensionnement et optimisation énergétique","Entretien des panneaux solaires"],
    meetIf: ["Vous envisagez d'installer des panneaux photovoltaïques.","Vous souhaitez étudier les possibilités de stockage de votre production électrique.","Vous recherchez des solutions de recharge pour véhicules électriques."],
    keywords: "solaire panneaux photovoltaïque toiture énergie batterie stockage borne recharge voiture véhicule électrique mobilité",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'jaco', displayOrder: 11, name: "Jaco", initials: 'JA',
    logoUrl: 'logos/jaco.png', plateColor: '#FFFFFF',
    primaryColor: '#B5462E', secondaryColor: '#FFFFFF', contrastColor: '#E88A6E', colorsConfirmed: false,
    website: 'https://jaco.brussels/', websiteNote: null,
    cats: ["food"], category: "Restauration • Trattoria italienne • Partenaire de la soirée",
    shortDescription: "La dolce vita s'invite à votre table ce soir.",
    detailedDescription: "Jaco propose une expérience de restauration inspirée de la cuisine italienne et de l'art de vivre « dolce vita ». À l'occasion de cette soirée LPGI, Jaco contribue à l'expérience gastronomique des participants.",
    services: ["Cuisine italienne","Esprit trattoria « dolce vita »","Expérience gastronomique de la soirée"],
    meetIf: ["Vous appréciez la cuisine et l'atmosphère des trattorias italiennes.","Vous souhaitez découvrir l'établissement derrière l'expérience culinaire de la soirée.","Vous recherchez une adresse à découvrir après l'événement."],
    experience: true, meetIfTitle: 'Vous devriez les découvrir si...', meetCta: 'Découvrir ce partenaire',
    keywords: "restaurant restauration nourriture repas cuisine italienne trattoria dolce vita food",
    representativeName: null, meetingLocation: null, contentSource: 'brief',
  },
  {
    id: 'nectar', displayOrder: 12, name: "NECTAR", initials: 'NE',
    logoUrl: 'logos/nectar.svg', plateColor: '#000000',
    primaryColor: '#FF751F', secondaryColor: '#FFFFFF', contrastColor: '#FF8C45', colorsConfirmed: true,
    website: 'https://event-nectar.com/', websiteNote: null,
    cats: ["food"], category: "Bar signature • Mixologie • Événementiel",
    shortDescription: "Nectar, l'art de sublimer chaque instant.",
    detailedDescription: "NECTAR propose des prestations événementielles haut de gamme autour d'un bar signature, d'une équipe professionnelle et d'expériences cocktails personnalisées.",
    services: ["Bar mobile avec mixologue","Cocktails signature, avec ou sans alcool","Accords cocktails et mets","Décoration et aménagement personnalisés","Prestations événementielles complémentaires, selon les besoins"],
    meetIf: ["Vous souhaitez proposer un bar mobile lors d'un événement.","Vous recherchez une expérience cocktails pour vos invités.","Vous souhaitez découvrir le prestataire derrière le bar de la soirée."],
    experience: true, meetIfTitle: 'Vous devriez les découvrir si...', meetCta: 'Découvrir ce partenaire',
    keywords: "bar mobile signature mixologie mixologue cocktails mocktails sans alcool accords mets décoration événement soirée",
    representativeName: null, meetingLocation: null, contentSource: 'document-officiel',
  },
];

// Matching déterministe besoin → partenaires (max 3) + catégorie pour « voir tous les correspondants »
window.LPGI_NEEDS = [
  {
    "id": "gestion",
    "label": "Gérer mes biens immobiliers.",
    "title": "Vous voulez mieux gérer vos biens ?",
    "cat": "immo",
    "recs": [
      [
        "colively",
        "Pour automatiser le suivi de la maintenance et centraliser les interventions."
      ],
      [
        "dcexpertises",
        "Pour vos états des lieux et évaluations immobilières."
      ],
      [
        "phoenixmaster",
        "Pour le nettoyage, l'entretien et la remise en état de vos biens."
      ]
    ]
  },
  {
    "id": "travaux",
    "label": "Rénover ou construire.",
    "title": "Vous préparez une rénovation ou une construction ?",
    "cat": "reno",
    "recs": [
      [
        "renovsecure",
        "Pour encadrer et vérifier votre projet avant d'engager les travaux."
      ],
      [
        "phoenixmaster",
        "Pour des travaux de rénovation et de remise en état."
      ],
      [
        "workpilot",
        "Pour trouver des renforts indépendants sur vos chantiers."
      ]
    ]
  },
  {
    "id": "electricite",
    "label": "Mettre mon installation électrique en conformité.",
    "title": "Vous avez des travaux électriques ou une mise en conformité ?",
    "cat": "reno",
    "recs": [
      [
        "asbuilt",
        "Pour vos travaux électriques domestiques et vos démarches de mise en conformité."
      ]
    ]
  },
  {
    "id": "chantiers",
    "label": "Je cherche des professionnels pour mes chantiers.",
    "title": "Vous cherchez des renforts pour vos chantiers ?",
    "cat": "reno",
    "recs": [
      [
        "workpilot",
        "Pour trouver des professionnels indépendants du bâtiment en renfort ou en remplacement."
      ]
    ]
  },
  {
    "id": "solaire",
    "label": "Je souhaite installer des panneaux solaires ou réduire ma consommation électrique.",
    "title": "Vous voulez passer au solaire ?",
    "cat": "energie",
    "recs": [
      [
        "belgosun",
        "Pour vos panneaux photovoltaïques, batteries de stockage et bornes de recharge."
      ]
    ]
  },
  {
    "id": "peb",
    "label": "J'ai besoin d'un certificat PEB.",
    "title": "Vous avez besoin d'un certificat PEB ?",
    "cat": "energie",
    "recs": [
      [
        "alenergy",
        "Pour une certification PEB officielle à Bruxelles, remise dès la visite selon conditions."
      ]
    ]
  },
  {
    "id": "digital",
    "label": "Digitaliser ou sécuriser mon activité.",
    "title": "Vous voulez digitaliser ou sécuriser votre activité ?",
    "cat": "tech",
    "recs": [
      [
        "phenixict",
        "Pour votre infrastructure, votre cybersécurité, la maintenance IT et le cloud."
      ],
      [
        "colively",
        "Pour digitaliser la maintenance immobilière grâce à l'automatisation et l'IA."
      ]
    ]
  },
  {
    "id": "visibilite",
    "label": "Développer ma visibilité.",
    "title": "Vous voulez développer votre visibilité ?",
    "cat": "com",
    "recs": [
      [
        "emkay",
        "Pour votre communication, vos contenus audiovisuels et vos événements professionnels."
      ]
    ]
  },
  {
    "id": "evenement",
    "label": "Organiser un événement.",
    "title": "Vous préparez un événement ?",
    "cat": "com",
    "recs": [
      [
        "emkay",
        "Pour l'organisation de votre événement professionnel et ses contenus."
      ],
      [
        "nectar",
        "Pour un bar mobile et une expérience cocktails pour vos invités."
      ],
      [
        "jaco",
        "Pour une adresse de cuisine italienne à découvrir."
      ]
    ]
  },
  {
    "id": "curieux",
    "label": "Découvrir les entreprises présentes.",
    "title": "Faites le tour des douze partenaires.",
    "cat": "all",
    "recs": []
  }
];
