// LPGI Partners — paramètres de la soirée (à éditer avant chaque édition)
window.LPGI_EVENT = {
  eventName: 'Afterwork LPGI',
  // URL publique cible (domaine à acquérir/vérifier avant de générer le QR code définitif).
  siteUrl: 'https://emkay-partners-lpgi.brussels/',
  siteTitle: 'EMKAY Partners × LPGI',
  shortName: 'EMKAY × LPGI',
  eventLabel: 'Ce soir',
  // Logo officiel LPGI (SVG/PNG). null = wordmark texte provisoire.
  lpgiLogoUrl: 'logos/lpgi.webp',
  // Signe distinctif réel de l'équipe d'accueil (badge, brassard, tenue…). null = message générique.
  staffIdentifier: null,
  // Logo EMKAY Partners pour la signature discrète du footer. null = texte seul.
  emkayLogoUrl: null,
  // Identité LPGI — #1D90B3 confirmé (theme-color de event.lpgi.club). Le reste est provisoire.
  theme: { primary: '#1D90B3', confirmed: ['primary'] },
};
