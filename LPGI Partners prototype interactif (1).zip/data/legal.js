// LPGI Partners — textes juridiques.
// Conventions : "- " = puce · "**" = ligne en gras · "[!] " = note interne À VALIDER (visible, à retirer avant publication).
window.LPGI_LEGAL = {
  legal: {
    title: 'Mentions légales', updated: 'Dernière mise à jour : 9 octobre 2026',
    sections: [
      { h: '1. Présentation du service', b: [
        "LPGI Partners est une interface numérique de découverte des entreprises partenaires, spécialement conçue pour un événement LPGI.",
        "Cette interface a été développée par EMKAY Partners afin de faciliter l'accès aux informations relatives aux partenaires et d'encourager les échanges professionnels pendant l'événement."] },
      { h: '2. Éditeur technique', b: [
        'La plateforme est développée et mise à disposition par :',
        '**EMKAY PARTNERS SRL',
        'Numéro d\'entreprise BCE : 1024.829.348',
        'Numéro de TVA : BE 1024.829.348',
        'Siège social : Avenue des Gerfauts 10, boîte 34, 1170 Watermael-Boitsfort, Belgique',
        'Téléphone : +32 451 09 56 50',
        'Adresse e-mail : Hello@visionhouse.be',
        'Site web de référence : https://www.visionhouse.be/',
        'Ces informations sont issues des données publiques de la Banque-Carrefour des Entreprises.',
        "[!] La responsabilité juridique de l'édition du service et les rôles respectifs d'EMKAY Partners et de l'organisateur LPGI doivent être confirmés dans leur accord."] },
      { h: '3. Hébergement', b: [
        'Le site est hébergé par :',
        "[!] Nom légal de l'hébergeur à renseigner",
        "[!] Adresse de l'hébergeur à renseigner",
        "[!] Site officiel de l'hébergeur à renseigner"] },
      { h: '4. Objet et utilisation', b: [
        "LPGI Partners est un service d'information et d'orientation à vocation événementielle.",
        'Il permet aux visiteurs de consulter la présentation des entreprises partenaires et d\'accéder à leurs sites web respectifs.',
        'Les informations publiées sont destinées à faciliter les prises de contact et ne constituent ni une recommandation commerciale individualisée, ni une garantie relative aux prestations des entreprises présentées.'] },
      { h: '5. Informations des partenaires', b: [
        'Les noms commerciaux, descriptions, logos, marques et liens présents sur la plateforme concernent les entreprises participantes.',
        'Les informations sont reproduites dans le cadre de leur présentation événementielle.',
        "EMKAY Partners veille à leur présentation fidèle mais ne garantit pas l'exactitude permanente de toutes les informations publiées par des tiers.",
        'Chaque entreprise demeure responsable des informations, offres, produits et services présentés sur son propre site.',
        'Les visuels et signes distinctifs des partenaires ne peuvent être réutilisés en dehors du cadre autorisé.'] },
      { h: '6. Propriété intellectuelle', b: [
        "Sous réserve des droits appartenant à LPGI, aux partenaires et à d'autres titulaires, les éléments originaux de conception, de développement et d'interface réalisés par EMKAY Partners sont protégés par les règles applicables en matière de propriété intellectuelle.",
        "Les droits d'utilisation et de propriété de la plateforme sont déterminés par les accords conclus entre les parties concernées.",
        'Toute reproduction ou exploitation non autorisée des éléments protégés est interdite, sauf exceptions prévues par la loi.'] },
      { h: '7. Liens externes', b: [
        'La plateforme contient des liens vers des sites internet gérés par des entreprises indépendantes.',
        "En cliquant sur ces liens, le visiteur quitte l'environnement LPGI Partners.",
        "Les conditions d'utilisation et politiques de confidentialité des sites tiers s'appliquent alors."] },
      { h: '8. Disponibilité', b: [
        "EMKAY Partners s'efforce d'assurer le bon fonctionnement technique du mini-site pendant la période prévue.",
        "Toutefois, des interruptions peuvent résulter de problèmes techniques, de connectivité ou d'interventions de maintenance.",
        "Aucune disponibilité ininterrompue n'est garantie."] },
      { h: '9. Droit applicable', b: ['Sous réserve des règles impératives applicables, le service relève du droit belge.'] },
      { h: '10. Contact', b: ["Pour toute question concernant l'interface technique ou une demande relative à son fonctionnement : Hello@visionhouse.be"] },
    ],
  },
  privacy: {
    title: 'Politique de confidentialité', updated: 'Dernière mise à jour : 9 octobre 2026',
    sections: [
      { h: '1. Objet', b: [
        "La présente politique explique comment les données peuvent être traitées lors de l'utilisation du mini-site LPGI Partners.",
        "L'application a été conçue pour permettre la découverte des partenaires et la consultation de leurs informations sans inscription obligatoire.",
        'La protection de la vie privée et la minimisation des données sont intégrées à sa conception.'] },
      { h: '2. Responsable du traitement', b: [
        'Pour les traitements techniques réalisés sous sa responsabilité dans le cadre de la plateforme, le contact de référence est :',
        '**EMKAY PARTNERS SRL',
        'BCE : 1024.829.348',
        'Avenue des Gerfauts 10, boîte 34, 1170 Watermael-Boitsfort, Belgique',
        'E-mail : Hello@visionhouse.be',
        "[!] La qualification exacte d'EMKAY Partners (responsable du traitement, sous-traitant ou responsable conjoint) doit être établie avec l'organisateur LPGI. Si l'organisateur détermine les finalités et qu'EMKAY agit pour son compte, adapter cette rubrique."] },
      { h: '3. Données traitées', b: [
        "La consultation des partenaires ne nécessite pas de fournir de nom, numéro de téléphone ou adresse e-mail.",
        'Selon le fonctionnement technique du service, certaines données peuvent néanmoins être traitées :',
        '- Adresse IP et informations techniques nécessaires aux connexions.',
        '- Date et heure des requêtes techniques.',
        "- Informations relatives au navigateur ou à l'appareil, si enregistrées dans les journaux du serveur.",
        "- Préférences et favoris enregistrés localement à la demande de l'utilisateur.",
        "- Informations volontairement communiquées si l'utilisateur contacte directement EMKAY Partners par e-mail.",
        "Les favoris ne sont pas transmis à l'organisateur par défaut."] },
      { h: '4. Finalités et bases juridiques', b: [
        "Les informations techniques nécessaires au fonctionnement et à la sécurité du service peuvent être traitées pour permettre l'accès au mini-site, assurer sa stabilité et prévenir les abus, sur la base de l'intérêt légitime lorsque celui-ci est applicable.",
        "Les favoris sont mémorisés localement pour fournir la fonctionnalité expressément demandée par l'utilisateur.",
        "Les messages envoyés volontairement par e-mail sont traités afin de répondre à la demande de leur auteur, selon la base juridique appropriée à la nature de l'échange.",
        "Aucune utilisation des données à des fins de prospection commerciale n'est prévue dans cette version de l'application."] },
      { h: "5. Mesure d'audience", b: [
        "La version initiale du mini-site n'intègre aucun pixel publicitaire, traceur marketing ou outil de profilage.",
        "Si un outil statistique est ajouté, cette politique sera actualisée afin d'indiquer son fournisseur, les données collectées, les finalités, les durées de conservation et, lorsqu'il est requis, le mécanisme de consentement."] },
      { h: '6. Stockage local', b: [
        "La fonction « Mes rencontres » peut enregistrer les partenaires sélectionnés dans l'espace de stockage du navigateur.",
        'Ce stockage permet au visiteur de retrouver sa sélection pendant la navigation.',
        "L'utilisateur peut supprimer ses favoris depuis l'application.",
        'Le stockage local peut également être supprimé depuis les paramètres de son navigateur.',
        "Seules les données nécessaires à une fonctionnalité expressément demandée sont enregistrées sans consentement préalable. Les autres usages du stockage local sont soumis aux règles applicables aux traceurs."] },
      { h: '7. Destinataires', b: [
        "Les données techniques nécessaires au fonctionnement peuvent être accessibles aux prestataires techniques autorisés intervenant dans l'hébergement ou la maintenance.",
        'Leurs accès sont limités aux besoins du service et encadrés par les engagements appropriés.',
        'Les partenaires ne reçoivent pas automatiquement les données de navigation ou les favoris des participants.'] },
      { h: '8. Durées de conservation', b: [
        'Les informations sont conservées uniquement pendant la durée nécessaire aux finalités concernées.',
        "Les favoris restent sur l'appareil jusqu'à leur suppression par l'utilisateur ou leur effacement par le navigateur.",
        "Les journaux techniques sont conservés selon une durée limitée, conformément à la politique effective de l'hébergeur.",
        '[!] Avant la mise en ligne, renseigner la durée réelle de conservation des journaux et des éventuelles sauvegardes.'] },
      { h: '9. Sécurité', b: [
        'Des mesures techniques et organisationnelles adaptées sont mises en place pour protéger le service.',
        "Elles comprennent notamment l'utilisation du protocole HTTPS, une gestion appropriée des accès techniques, la limitation des données collectées et la sécurisation de l'hébergement."] },
      { h: '10. Transferts internationaux', b: [
        "[!] La localisation des prestataires et des serveurs utilisés doit être vérifiée.",
        "Si des données personnelles sont transférées vers un pays situé hors de l'Espace économique européen, les garanties prévues par la réglementation applicable doivent être identifiées et documentées."] },
      { h: '11. Droits des utilisateurs', b: [
        'Dans les conditions prévues par le RGPD, les personnes concernées peuvent demander :',
        "- L'accès à leurs données personnelles.",
        '- La rectification de données inexactes.',
        "- L'effacement de leurs données.",
        '- La limitation de certains traitements.',
        "- L'opposition à un traitement fondé sur l'intérêt légitime.",
        '- La portabilité lorsque ce droit est applicable.',
        '- Le retrait de leur consentement lorsqu\'un traitement repose sur cette base.',
        "Toute demande relative à un traitement relevant d'EMKAY Partners peut être adressée à : Hello@visionhouse.be",
        'Les demandes seront examinées dans les délais légaux applicables.'] },
      { h: '12. Réclamation', b: [
        "Si une personne estime que ses données sont traitées en violation de la réglementation applicable, elle peut introduire une réclamation auprès de l'Autorité de protection des données belge.",
        'Site officiel : https://www.autoriteprotectiondonnees.be/'] },
      { h: '13. Sites externes', b: [
        'Les liens vers les partenaires redirigent les visiteurs vers leurs propres sites web.',
        'Ces sites disposent de leurs propres pratiques de traitement de données et politiques de confidentialité.',
        "LPGI Partners n'est pas responsable des traitements indépendamment réalisés par ces entreprises."] },
      { h: '14. Modification de la politique', b: [
        "Cette politique peut être actualisée en cas de modification du fonctionnement de l'application, de ses prestataires ou des traitements effectués.",
        'La date de dernière mise à jour sera modifiée en conséquence.'] },
      { h: 'Cookies et stockage local', id: 'cookies', b: [
        "LPGI Partners ne prévoit pas, dans sa version initiale, l'utilisation de cookies publicitaires ou de traceurs destinés à établir des profils de navigation.",
        "Certaines informations peuvent être conservées localement sur votre appareil lorsque vous utilisez une fonctionnalité comme « Mes rencontres ».",
        "Ce stockage sert uniquement à conserver les partenaires que vous avez choisi d'enregistrer. Vous pouvez effacer cette sélection à tout moment.",
        "Des traitements techniques nécessaires à la sécurité et à la disponibilité du service peuvent également être réalisés par l'infrastructure d'hébergement."] },
    ],
  },
};
